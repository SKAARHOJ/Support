#!/bin/bash

# Install kernel headers and image
sudo dpkg -i linux-headers-6.1.77-v8-udlpatch+_6.1.77-v8-udlpatch+-2_arm64.deb
sudo dpkg -i linux-image-6.1.77-v8-udlpatch+_6.1.77-v8-udlpatch+-2_arm64.deb
sudo dpkg -i linux-libc-dev_6.1.77-v8-udlpatch+-2_arm64.deb

# Copy kernel8udl.img to /boot/firmware/
sudo cp kernel8udl.img /boot/firmware/

# Add kernel=kernel8udl.img to /boot/config.txt
echo "kernel=kernel8udl.img" | sudo tee -a /boot/config.txt

# Modify LightDM configuration
sudo sed -i 's/greeter-session=pi-greeter-wayfire/greeter-session=pi-greeter/' /etc/lightdm/lightdm.conf
sudo sed -i 's/user-session=LXDE-pi-wayfire/user-session=LXDE-pi-x/' /etc/lightdm/lightdm.conf
sudo sed -i 's/autologin-session=LXDE-pi-wayfire/autologin-session=LXDE-pi-x/' /etc/lightdm/lightdm.conf

echo "Kernel installation and configuration completed."

xorg_conf="/etc/X11/xorg.conf"
backup_suffix=".bak"

# Check if xorg.conf exists
if [ -e "$xorg_conf" ]; then
    # Backup xorg.conf
    backup_file="$xorg_conf$backup_suffix"
    cp "$xorg_conf" "$backup_file"
    echo "Backup created: $backup_file"
else
    # Create xorg.conf with specified content
    echo 'Section "Device"
    Identifier "DisplayLink"
    Driver "fbdev"
    Option "fbdev" "/dev/fb0"
EndSection' | sudo tee "$xorg_conf" > /dev/null
    echo "xorg.conf created"
fi

# Check if xorg.conf content matches
expected_content='Section "Device"
    Identifier "DisplayLink"
    Driver "fbdev"
    Option "fbdev" "/dev/fb0"
EndSection'

actual_content=$(cat "$xorg_conf" 2>/dev/null)

if [ "$actual_content" = "$expected_content" ]; then
    echo "xorg.conf content matches."
else
    echo "Warning: xorg.conf content doesn't match the expected content."
fi

echo "Please type in the IP and Port of your SKAARHOJ Touch Raw Panel application.(Example:192.168.11.5:7952)"
echo "Browser will try to reach this IP on startup..."
read ipToUse
echo "Writing display.desktop with IP=$ipToUse"

cd /etc/xdg/autostart/
file2="./display.desktop"

if [ -f "$file2" ] ; then
    echo "display.desktop already exists"
    echo "Deleting old display.desktop"
    rm "$file2"
fi

echo "Creating display.desktop"
touch $file2
echo "[Desktop Entry]" >> $file2
echo "Name=Chrome" >> $file2
echo "Exec=chromium-browser --app=http://$ipToUse --start-fullscreen" >> $file2

cat $file2

echo "Disabling screen-saver"

cd /etc/xdg/lxsession/LXDE-pi/
file3="./autostart"

if [ -f "$file3" ] ; then
    echo "autostart already exists"
    echo "Deleting old autostart"
    rm "$file3"
fi

echo "Creating autostart"
echo touch $file3
echo "@lxpanel --profile LXDE-pi" >> $file3
echo "@pcmanfm --desktop --profile LXDE-pi" >> $file3
echo "@xscreensaver -no-splash" >> $file3
echo "@xset s off" >> $file3
echo "@xset -dpms" >> $file3

cat $file3

echo "Done!"
echo "Do not forget to unplug your HDMI monitor if it is still attached!"
echo "Please reboot your system!"
# Run sync command
sync
echo "Sync completed."

# Prompt for reboot
read -p "Do you want to reboot now? (y/n): " choice
case "$choice" in
  y|Y ) sudo reboot;;
  n|N ) echo "You can manually reboot later.";;
  * ) echo "Invalid option. You can manually reboot later.";;
esac
